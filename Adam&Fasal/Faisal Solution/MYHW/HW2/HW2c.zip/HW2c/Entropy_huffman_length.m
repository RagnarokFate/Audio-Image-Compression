path = uigetfile('*.bmp');
im = imread(path);
img = im2double(im);
img_vector = img(:);
S1 = entropy_length(img_vector);
S2 = huffman_length(img_vector);


randomVector = randi([0 256],1,256^2);
randomVector = uint8(randomVector);
S3 = round(entropy_length(randomVector));
S4 = hufman_length(randomVector);

function S2 = entropy_length(v)
    [~,prob]=help(v);
    S2=0;
        for i=1:length(prob)
            S2=S2-prob(i)*log2(prob(i));
        end
    S2=S2*length(v);
end
function S2 = huffman_length(v)
    [sym_table,prob_by_sym] = help(v);
    [~,avg_bit_per_sym]=huffmandict(sym_table,prob_by_sym);
    S2=avg_bit_per_sym*length(v);
end
function [table,probb] = help(v)

    sorted = sort(v);
    index = 1;
    probb(1) = sorted(1);
    probb(1) = 1;
    for i=2:length(sorted)
        if sorted(i-1) == sorted(i)
            probb(index)=probb(index)+1;
        else
            index = index + 1;
            table(index) = sorted(i);
            probb(index) = 1;
        end
    end
        
    probb = probb / length(v);

end